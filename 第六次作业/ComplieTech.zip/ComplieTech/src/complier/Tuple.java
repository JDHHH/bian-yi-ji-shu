package complier;

public class Tuple<T1,T2> {
    T1 key=null;
    T2 val=null;
    public Tuple(T1 l,T2 r){
        this.key=l;
        this.val=r;
    }
    @Override
    public String toString(){
        return "["+key.toString()+","+val.toString()+"]";
    }
    @Override
    public boolean equals(Object obj){
        if(!(obj instanceof Tuple)){
            return false;
        }else{
            if(((Tuple)obj).key.equals(key) && ((Tuple)obj).val.equals(val)){
                return true;
            }else{
                return false;
            }
        }
    }
    @Override
    public int hashCode(){
        return key.toString().length()+val.toString().length();
    }
}
