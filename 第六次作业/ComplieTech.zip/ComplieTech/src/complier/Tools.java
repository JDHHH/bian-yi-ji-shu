package complier;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Tools {
    public static Integer getKey_Pram(Map<String, Set<Tuple<String,String>>> map,Set<Tuple<String,String>> v) {
        String key = "";

        for (Map.Entry<String, Set<Tuple<String,String>>> m :map.entrySet())  {
            if (m.getValue().equals(v)) {
                key = m.getKey();
            }}

        return Integer.parseInt(key.substring(1));

    }
    public static Integer getKey_Exp( Map<Integer,Tuple<String,String>> map,Tuple<String,String> v) {
        Integer key = -1;

        for (Map.Entry<Integer,Tuple<String,String>> m :map.entrySet())  {
            if (m.getValue().equals(v)) {
                key = m.getKey();
            }}

        return key;

    }
    public static Object getKey(Map<Object, Object> map,Object v) {
        Object key = "";

        for (Map.Entry<Object, Object> m :map.entrySet())  {
            if (m.getValue().equals(v)) {
                key = m.getKey();
            }}

        return key;

    }
}
