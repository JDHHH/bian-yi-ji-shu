package complier;

import complier.automata.InputItem;
import complier.tokenlization.WordTuple;
import complier.tokenlization.tokenlizer;
import complier.tokenlization.IReductionStrategy;

import javax.management.Query;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

enum FromBottomItem_ProcessWay{
    ACC,
    S,
    R,
    GOTO
}
class FromBottomTableItem{
    public FromBottomItem_ProcessWay pw;
    public String targetCon="";
    public int state=-1;
    public FromBottomTableItem(FromBottomItem_ProcessWay pw,String targetCon,int state){
        this.pw=pw;
        this.targetCon=targetCon;
        this.state=state;
    }
    @Override
    public String toString(){
        return targetCon+":"+state+":"+pw;
    }
}
public class CFGAnalyer {
    //打印分析表(观察用)
    public static void printAnalyzeTable(String[][] table, Map<String,Integer> tmap, Map<String,Integer> ntmap){
        System.out.print("\t");
        for(String s:tmap.keySet()){
            System.out.print(s+"\t");
        }
        System.out.println();
        for(String s1:ntmap.keySet()){
            System.out.print(s1+"\t");
            for (String s2:tmap.keySet()){
                System.out.print(table[ntmap.get(s1)][tmap.get(s2)]+"\t");
            }
            System.out.println();
        }


    }

    //获取某个上下文无关文法的所有First集和Follow集
    public static Map<String,Map<String, Set<String>>> getFullFirstAndFollowSet(String input, String begin){

        Map<String,Set<String>> firstmap=new HashMap<>();
        Map<String,Set<String>> followmap=new HashMap<>();
        //calc first
        System.out.println("calc follow...");
        Map<String, List<String>> infermap=CFGAnalyze(input);
        if(!infermap.keySet().contains(begin)) throw new RuntimeException();

        for(String s:infermap.keySet()){
            System.out.println("get first:"+s);
            Set<String> first_tmp=getFirst(input,s);
            System.out.println(first_tmp);
            firstmap.put(s,first_tmp);
            followmap.put(s,new HashSet<>());
        }
        System.out.println("Get first finish...");
        System.out.println("calc follow...");
        //put $ to begin
        followmap.get(begin).add("$");
        int count=0;
        while (true) {
            for (String s : infermap.keySet()) {
                //System.out.println("process :" + s);

                for (String item : infermap.get(s)) {
                    //System.out.println(item);

                    for (String s2 : infermap.keySet()) {
                        //2
                        if (item.indexOf(s2) < 0 || (item.indexOf(s2) + s2.length()) >= item.length() ||
                                item.charAt(item.indexOf(s2) + 1) == '\'') {
                        } else {
                            String targetfirst = item.charAt(item.indexOf(s2) + s2.length()) +
                                    ((item.indexOf(s2) + s2.length() + 1) < item.length() &&
                                            item.charAt(item.indexOf(s2) + s2.length() + 1) == '\'' ? "\'" : "");
                            //System.out.println("find " + s2 + " put " + targetfirst + " 's first set");
                            if (!infermap.keySet().contains(targetfirst)) {
                                int precount = followmap.get(s2).size();
                                followmap.get(s2).add(targetfirst);
                                followmap.get(s2).remove("ε");
                                if (precount != followmap.get(s2).size()) count = 0;
                            } else {
                                int precount = followmap.get(s2).size();
                                followmap.get(s2).addAll(firstmap.get(targetfirst));
                                followmap.get(s2).remove("ε");
                                if (precount != followmap.get(s2).size()) count= 0;
                            }
                        }

                        //3
                        String tail = item.charAt(item.length() - 1) == '\'' ?
                                item.charAt(item.length() - 2) + "\'" :
                                String.valueOf(item.charAt(item.length() - 1));
                        if (firstmap.containsKey(tail)) { //末尾是终结符
                            //System.out.println("Follow(" + s + ")->Follow(" + tail + ")");
                            int precount = followmap.get(tail).size();
                            followmap.get(tail).addAll(followmap.get(s));
                            followmap.get(tail).remove("ε");
                            if (precount != followmap.get(tail).size()) count =0 ;
                        }
                        //处理末尾可以推出空串的情况
                        for(String ki:firstmap.keySet()){
                            if(item.indexOf(ki)<0 ||
                                    item.indexOf(ki)==item.length()-ki.length()
                                    ||
                                    (item.indexOf(ki)+1<item.length() && item.charAt(item.indexOf(ki)+1)=='\'')) continue;
                            //System.out.println("##"+s +"+->"+ki+" "+item.substring(item.indexOf(ki)+1)+" ["+item);
                            String target=item.substring(item.indexOf(ki)+1);
                            if(!followmap.containsKey(ki) || !judgeEpslionDeduct( target,infermap)) continue;
                            int preCount=followmap.get(ki).size();
                            followmap.get(ki).addAll(followmap.get(s));
                            followmap.get(ki).remove("ε");
                            if(followmap.get(ki).size()!=preCount) count=0;
                        }


                    }

                }
            }
            if(count>1){
                break;
            }else{
                count++;
            }
        }
        for (String s : infermap.keySet()) {
            System.out.println(s+" "+followmap.get(s));
        }
        Map<String,Map<String,Set<String>>> result=new HashMap<>();
        result.put("FIRST",firstmap);
        result.put("FOLLOW",followmap);
        return result;
    }
    //返回一个上下文无关文法的各项信息  key=非终结符 val=推导式map
    public static Map<String,List<String>> CFGAnalyze(String cfg){
        Map<String,List<String>> cfgmap=new HashMap<>();
        //System.out.println("/////////////////Input S/////////////////");
        //System.out.println(cfg);
        //System.out.println("/////////////////Input E/////////////////");
        String[] cfgs=cfg.split("\n");
        for(int i=0;i<cfgs.length;i++){
            //System.out.println("====Process S====");
            //System.out.println(cfgs[i]);
            String[] rl=cfgs[i].split("->");
            if(rl.length!=2){
                rl=cfgs[i].split("→");
            }
            if(rl.length!=2) throw new RuntimeException();

            String[] rs=rl[1].split("\\|");
            //  System.out.print(rl[0]+",");

            if(cfgmap.containsKey(rl[0])) throw new RuntimeException();
            List<String> rarr=new ArrayList<>();
            for(String r:rs){
                rarr.add(r);
                //System.out.print(" "+r);
            }
            cfgmap.put(rl[0],rarr);
            //System.out.println();




            //System.out.println("====Process E====");
        }
        return cfgmap;
    }




    //获取某个非终结符的First集合
    public static Set<String> getFirst(String input,String S){
        System.out.println(input);
        Map<String,List<String>> cfgmap=CFGAnalyze(input);

        Set<String> first=new HashSet<>();

        if(!cfgmap.containsKey(S)) throw new RuntimeException();

        List<String> cfgDeduction=cfgmap.get(S);
        for(String cfgItem:cfgDeduction){
            //System.out.println("process: "+cfgItem);
            if(cfgItem.compareTo("ε")==0){
                first.add("ε");
                System.out.println("put ε");
                continue;
            }
            String mostLeft=cfgItem.substring(0,1);

            if('A'<=mostLeft.charAt(0) && mostLeft.charAt(0)<='Z' ){
                if(cfgItem.length()>=2 && cfgItem.charAt(1)!='\''){
                    //System.out.println("Found "+mostLeft);
                    if(!S.equals(mostLeft)){
                        first.addAll(getFirst(input,mostLeft));
                    }
                }else if(cfgItem.length()==1){
                    //System.out.println("Found "+mostLeft);
                }
                else{
                   // System.out.println("Found "+mostLeft+'\'');
                    first.addAll(getFirst(input,mostLeft+"'"));
                }
            }else{

                //最左不是非终结符
                if(mostLeft.charAt(0)<='z' && mostLeft.charAt(0)>='a'){
                    for(int i=1;i<cfgItem.length();i++){
                        //System.out.println("curr="+mostLeft);
                        if(cfgItem.charAt(i)>'z' || cfgItem.charAt(i)<'a'){
                            break;
                        }else{
                            mostLeft+=String.valueOf(cfgItem.charAt(i));
                             //System.out.println("curr="+mostLeft);
                        }

                    }
                    //System.out.println("put "+mostLeft);
                    first.add(mostLeft);
                }else{
                    //System.out.println("put "+mostLeft);
                    first.add(mostLeft);
                }
            }

        }
        //System.out.println("FIRST:"+first);
        return first;
    }

    //判断一个式子是否能推导出空串
    public static boolean judgeEpslionDeduct(String input,Map<String,List<String>> cfg){
        if("ε".equals(input)) return true;
        Set<String> deductset=new HashSet<>();
        deductset.add(input);
        while(true){
            int c=deductset.size();
            for(String d:deductset){  //处理集合中每个式子
                Set<String> nset=new HashSet<>();
                for(int i=0;i<d.length();i++){  //处理每个符号
                    String cur=d.substring(i,i+
                            (
                                    ((i+1<d.length())&& d.charAt(i+1)=='\'')
                                            ?2:1)
                    );

                    if(!cfg.containsKey(cur)) {
                        if(nset.isEmpty()) nset.add(cur);
                        else{
                            for(String ss:nset){
                                ss+=cur.replace("ε","");
                            }
                        }
                        continue; //当前符号不可推断（看做终结符）
                    }
                    List<String> infers=cfg.get(cur);

                    if(nset.isEmpty()){
                        for(String s:infers){
                            nset.add(s.replace("ε",""));
                        }
                    }else{
                        for(String s:infers){
                            for(String ss:nset){
                                ss+=s.replace("ε","");
                            }
                        }
                    }

                    //System.out.println(nset+" "+deductset);
                    if(nset.contains("")) return true;
                    deductset.addAll(nset);
                }

            }
            int nc=deductset.size();
            if(c==nc) break;
        }
        return false;
    }

    //绘制预测分析表
    public static Map<String,Object> drawTable(String input){
        Map<String,Map<String,Set<String>>> ff=getFullFirstAndFollowSet(input,"E");
        Map<String,Set<String>> firstmap=ff.get("FIRST");
        Map<String,Set<String>> followmap=ff.get("FOLLOW");

        Map<String,List<String>> cfgmap=CFGAnalyze(input);
        Set<String> TerminalSet=new HashSet<>();
        //获取所有终结符
        for(String t:cfgmap.keySet()){
            List<String> ls=cfgmap.get(t);
            for(String s:ls){
                String cur="";
                for(int i=0;i<s.length();i++){
                    char c=s.charAt(i);
                    if((c>='A' && c<='Z' || c=='\'')) {
                        if(!("".equals(cur))) System.out.println(cur);
                        cur="";
                        continue;
                    }
                    if(c>='a' && c<='z'){
                        cur+=c;
                        continue;
                    }
                    //System.out.println(s.charAt(i));
                    TerminalSet.add(String.valueOf(s.charAt(i)));

                }
                if(!("".equals(cur))) TerminalSet.add(cur);
                cur="";
            }
        }
        TerminalSet.remove("ε");
        TerminalSet.add("$");
        System.out.println(TerminalSet);


        //为终结符与非终结符编号
        Map<String,Integer> terminalmap=new HashMap<>();
        Map<String,Integer> notTerminalmap=new HashMap<>();
        int i=0;
        for(String t:cfgmap.keySet()){
            notTerminalmap.put(t,i);
            i++;
        }
        System.out.println(notTerminalmap);
        i=0;
        for(String t:TerminalSet){
            terminalmap.put(t,i);
            i++;
        }
        System.out.println(terminalmap);
        String[][] table=new String[notTerminalmap.keySet().size()][terminalmap.keySet().size()];


        //fill table
        for(String s1:cfgmap.keySet()){
            List<String> items=cfgmap.get(s1);
            for(int x=0;x<items.size();x++){
                String s2=items.get(x);
                String fc=String.valueOf(s2.charAt(0));
                while (fc.charAt(fc.length()-1)<='z' && fc.charAt(fc.length()-1)>='a'){
                    if(fc.length()<s2.length()){
                        fc+=s2.charAt(fc.length());
                    }else{
                        break;
                    }
                }
                if(fc.length()<s2.length() && fc.charAt(fc.length()-1)<='Z' && fc.charAt(fc.length()-1)>='A' && s2.charAt(fc.length())=='\''){
                    fc+="\'";
                }

                if(!(cfgmap.keySet().contains(fc))){
                    System.out.println(s1+":"+fc);
                    if(fc.equals("ε")){
                        System.out.print("process:"+s1+" "+fc+" ");
                        Set<String> cfollow=followmap.get(s1);
                        System.out.println(cfollow);
                        for(String terminal:cfollow){
                            table[notTerminalmap.get(s1)][terminalmap.get(terminal)]=String.valueOf(x);
                        }
                    }else{
                        table[notTerminalmap.get(s1)][terminalmap.get(fc)]=String.valueOf(x);
                    }
                }else{
                    System.out.print("process:"+s1+" "+fc+" ");
                    Set<String> cfirst=firstmap.get(fc);
                    System.out.println(cfirst);
                    for(String terminal:cfirst){
                        table[notTerminalmap.get(s1)][terminalmap.get(terminal)]=String.valueOf(x);
                    }
                }


            }
        }
        //fill synch
        for(String s1:notTerminalmap.keySet()){
            Set<String> follow=followmap.get(s1);
            for(String s2:follow){
                if(table[notTerminalmap.get(s1)][terminalmap.get(s2)]==null){
                    table[notTerminalmap.get(s1)][terminalmap.get(s2)]="-1";
                }
            }

        }
        Map<String ,Object> result=new HashMap<>();
        result.put("TABLE",table);
        result.put("CODE_TERMINAL",terminalmap);
        result.put("CODE_NOTTERMINAL",notTerminalmap);
        result.put("CFGMAP",cfgmap);
        return result;
    }

    //自上而下分析一个式子
    public static void analyzeTry_fromTop(String cfginput,String inputstr){

        //首先绘制预测分析表,以及获取各项信息
        Map<String,Object> result=drawTable(cfginput);
        //获取表数据
        String[][] table=(String[][])result.get("TABLE");
        //获取终结符标号过的map
        Map<String,Integer> terminalmap=(HashMap)result.get("CODE_TERMINAL");
        //获取非终结符标号过的map
        Map<String,Integer> notTerminalmap=(HashMap)result.get("CODE_NOTTERMINAL");
        //获取上下文无关文法推导式map
        Map<String,List<String>> cfgmap=(HashMap)result.get("CFGMAP");
        //打印一下分析表
        printAnalyzeTable(table,terminalmap,notTerminalmap);

        //初始化栈
        Stack<String> stack=new Stack<>();
        stack.push("$");
        stack.push("E");


        //=============================将输入弄成字符输入队列 begin==========================
        Queue<String> inputqueue=new LinkedList<String>();
        String curchars="";
        int time=0;
        for(int i=0;i<inputstr.length();i++){
            char cc=inputstr.charAt(i);
            if(cc<='z' && cc>='a'){
                curchars+=cc;
            }else
            if(cc<='Z' && cc>='A'){
                if(!("".equals(curchars))){
                    inputqueue.add(curchars);
                }
                if(i+1<inputstr.length() && inputstr.charAt(i+1)=='\''){
                    inputqueue.add(curchars+"'");
                    i++;
                }
                curchars="";
            }else {
                if(!("".equals(curchars))){
                    inputqueue.add(curchars);
                }
                inputqueue.add(String.valueOf(cc));
                curchars="";
            }
        }
        if(!("".equals(curchars))){
            inputqueue.add(curchars);
        }
        inputqueue.add("$");
        //=============================将输入弄成字符输入队列 end==========================



        System.out.println("============Algorithm begin==========");
        System.out.println("stack: "+stack+"  queue: "+inputqueue);
        int step=1;
        String recongnize="";
        while(!stack.empty()){
            stack.push(stack.pop().replaceAll("ε",""));
            if(stack.peek().equals("")) stack.pop();
            System.out.println("step "+step+": "+"stack: "+stack+"  queue: "+inputqueue);
            if(stack.peek().equals("$") && inputqueue.peek().equals("$")){
                stack.pop();
                inputqueue.poll();

                step++;
                continue;
            }
            //对应都是终结符
            if(terminalmap.containsKey(stack.peek()) && terminalmap.containsKey(inputqueue.peek())){
                recongnize+=stack.pop();
                inputqueue.poll();
                step++;
                continue;
            }
            //表中无数据
            if(table[notTerminalmap.get(stack.peek())][terminalmap.get(inputqueue.peek())]==null){
                System.out.println("["+stack.peek()+" & "+inputqueue.peek()+"]表中无信息，从输入队列删除");
                inputqueue.poll();
                step++;
                time++;
                continue;
            }

            //在表中对应同步信号
            if(table[notTerminalmap.get(stack.peek())][terminalmap.get(inputqueue.peek())]=="-1"){
                System.out.println("["+stack.peek()+" & "+inputqueue.peek()+"] 发现同步信号，弹栈");
                stack.pop();
                step++;
                time++;
                continue;
            }

            //在表中对应正常推导
            int ind=Integer.valueOf(table[notTerminalmap.get(stack.peek())][terminalmap.get(inputqueue.peek())]);
            if(ind>=0){
                System.out.print("["+stack.peek()+" & "+inputqueue.peek()+"] 发现正常推导式:");
                System.out.println(stack.peek()+"->"+cfgmap.get(stack.peek()).get(ind));
                String newitem=cfgmap.get(stack.peek()).get(ind);

                Stack<String> cstack=new Stack<>();
                curchars="";
                for(int i=0;i<newitem.length();i++){
                    char cc=newitem.charAt(i);

                    if(cc<='z' && cc>='a'){
                        curchars+=cc;
                    }else
                    if(cc<='Z' && cc>='A'){
                        if(!("".equals(curchars))){
                            cstack.push(curchars);
                            //System.out.println(curchars);
                        }
                        if(i+1<newitem.length() && newitem.charAt(i+1)=='\''){
                            cstack.push(cc+"'");
                            i++;
                        }else{
                            cstack.push(String.valueOf(cc));
                        }
                        curchars="";
                    }else {
                        if(!("".equals(curchars))){
                            cstack.push(curchars);
                        }
                        cstack.push(String.valueOf(cc));
                        curchars="";
                    }
                }
                if(!("".equals(curchars))){
                    cstack.push(curchars);
                }
                stack.pop();
                while (!cstack.empty()){
                    stack.push(cstack.pop());
                }
                step++;
                continue;
            }




        }
        System.out.println("语法正常识别,其中遇到"+time+"次错误\n输入数据为:"+inputstr+",识别到的语句为:"+recongnize);
    }






    public static Queue<String> getInputQuery(String inputstr){
        String cur="";
        Queue<String> result=new LinkedList<>();
        for(int i=0;i<inputstr.length();i++){
            char cc=inputstr.charAt(i); //获取当前位置字符
            if(cc<='z' && cc>='a'){
                cur+=cc;
            }else
            if(cc<='Z' && cc>='A'){
                if(!("".equals(cur))){
                    result.add(cur);
                }

                if(i+1<inputstr.length() && inputstr.charAt(i+1)=='\''){
                    result.add(String.valueOf(cc)+"'");
                    i++;
                }else{
                    result.add(String.valueOf(cc));
                }
                cur="";
            }else {
                if(!("".equals(cur))){
                    result.add(cur);
                }
                result.add(String.valueOf(cc));
                cur="";
            }
        }
        if(!("".equals(cur))){
            result.add(cur);
        }
        return result;
    }

    //需要的参数: 编号过的产生式集合、项目集、转换边集合
    public static Map<String,Object> drawTable_fromBottom(Map<String,List<String>> cfgmap,
                                            Map<Integer,Tuple<String,String>> numberedCFG,
                                            Map<String,Set<Tuple<String,String>>> pramsMap,
                                            Map<Integer,Set<TransitionEdge>> transitionsMap,
                                            Map<String, Set<String>> followSet,
                                            String S_state){
        Map<String,Object> result=new HashMap<>();
        Set<String> TerminalSet=new HashSet<>();
        Set<String> noTerminalSet=new HashSet<>();
        //获取所有终结符
        for(String t:cfgmap.keySet()){
            List<String> ls=cfgmap.get(t);
            for(String s:ls){
                String cur="";
                for(int i=0;i<s.length();i++){
                    char c=s.charAt(i);
                    if((c>='A' && c<='Z' || c=='\'')) {
                        if(!("".equals(cur))) System.out.println(cur);
                        cur="";
                        continue;
                    }
                    if(c>='a' && c<='z'){
                        cur+=c;
                        continue;
                    }
                    //System.out.println(s.charAt(i));
                    TerminalSet.add(String.valueOf(s.charAt(i)));

                }
                if(!("".equals(cur))) TerminalSet.add(cur);
                cur="";
            }
        }
        TerminalSet.add("$");
        System.out.println("获取终结符"+TerminalSet);
        //获取非终结符
        for(String n:cfgmap.keySet()){
            noTerminalSet.add(n);
        }
        System.out.println("获取非终结符"+noTerminalSet);
        result.put("TerminalSet",TerminalSet);
        result.put("NotTerminalSet",noTerminalSet);

        Map<Integer,Set<FromBottomTableItem>> tableInf=new HashMap<>();


        //填充表信息
        for(int i=0;i<pramsMap.size();i++){
            System.out.println("I"+i+"========================");
            Set<FromBottomTableItem> fromBottomTableItemSet=new HashSet<>();

            System.out.println(transitionsMap.get(i));
            for(TransitionEdge transitionEdge:transitionsMap.get(i)){
                //处理goto与shift
                if(cfgmap.containsKey(transitionEdge.context)){
                    fromBottomTableItemSet.add(new FromBottomTableItem(FromBottomItem_ProcessWay.GOTO,transitionEdge.context,transitionEdge.to));
                    //System.out.println("非终结符:"+transitionEdge.context);
                }else{
                    if(TerminalSet.contains(transitionEdge.context)){
                        fromBottomTableItemSet.add(new FromBottomTableItem(FromBottomItem_ProcessWay.S,transitionEdge.context,transitionEdge.to));
                       // System.out.println("终结符:"+transitionEdge.context);
                    }
                }


            }
            //处理规约与acc
            for(Tuple<String,String> tuple:pramsMap.get("I"+i)){
                System.out.println(tuple);
                //需要归约
                System.out.println();
                if((tuple.val.indexOf(".")==tuple.val.length()-1)
                 || ((tuple.val.indexOf("}",tuple.val.indexOf("."))==tuple.val.length()-1)) && tuple.val.charAt(tuple.val.indexOf(".")+1)=='{'
                ){
                    System.out.println("IN I"+i+": >>>>>>>>>>>>>>>>>>产生归约");
                    if(tuple.key.equals(S_state)){
                        //填充ACC
                        System.out.println("Acc");
                        fromBottomTableItemSet.add(new FromBottomTableItem(FromBottomItem_ProcessWay.ACC,"$",-3));
                    }else{
                        //获取归约的follow
                        Set<String> follow_cur=followSet.get(tuple.key);
                        System.out.println("get follow of "+tuple.key+"="+follow_cur);
                        //获取对应表达式编号
                        String val2=tuple.val.replaceAll("\\{[a-zA-Z]\\d*\\}","");
                        int code=Tools.getKey_Exp(numberedCFG,new Tuple<String,String>((String)tuple.key,
                                (String)val2.substring(0,val2.length()-1)));
                        System.out.println("get coded of "+tuple.key+"->"+tuple.val.substring(0,tuple.val.length()).replaceAll("\\{[a-zA-Z]\\d*\\}","")+" ="+code);
                        for(String f:follow_cur){
                            fromBottomTableItemSet.add(new FromBottomTableItem(FromBottomItem_ProcessWay.R,
                                    f,code));
                        }

                    }


                }
            }
            tableInf.put(i,fromBottomTableItemSet);

        }

        System.out.println("Calc Finish........\n===========================================================");
        System.out.println("Step 5:Print Table....");
        result.put("TableInf",tableInf);
        printTable_fromBottom(result);
        return result;
    }


    public static void printTable_fromBottom(Map<String,Object> tableInf){
        Set<String> TerminalSet=(Set<String>) tableInf.get("TerminalSet");
        Set<String> noTerminalSet= (Set<String>) tableInf.get("NotTerminalSet");
        Map<Integer,Set<FromBottomTableItem>> items=(Map<Integer, Set<FromBottomTableItem>>) tableInf.get("TableInf");
        //打印表头
        System.out.print("状态\t| ");
        for(String t:TerminalSet){
            System.out.print(t+"\t");
        }
        System.out.print(" | ");
        for(String t:noTerminalSet){
            System.out.print(t+"\t");
        }
        System.out.println();
        System.out.println("--------------------------------------------------------");
        //打印表项
        for(int i=0;i<items.size();i++){
            Set<FromBottomTableItem> line=items.get(i);
            System.out.print(i+"\t|");
            if(line==null || line.size()==0){
                continue;
            }

            for(String t:TerminalSet){
                //寻找对应t的项
                for(FromBottomTableItem t2:line){
                    if(t2.targetCon.equals(t)){
                        switch (t2.pw){
                            case ACC:
                                System.out.print("acc");
                                break;
                            case S:
                                System.out.print("s"+t2.state);
                                break;
                            case R:
                                System.out.print("r"+t2.state);
                                break;
                        }
                    }
                }
                System.out.print("\t");
            }
            System.out.print(" | ");
            for(String t:noTerminalSet){
                //寻找对应t的项
                for(FromBottomTableItem t2:line){
                    if(t2.targetCon.equals(t)){
                        switch (t2.pw){
                            case GOTO:
                                System.out.print(t2.state);
                                break;
                        }
                    }
                }
                System.out.print("\t");
            }
            System.out.println();
        }
    }

    public static String shiftPointForward(String input){
        String behind=getBehindPoint(input);
        if(input.indexOf(".")<0) return "";
        StringBuilder sb=new StringBuilder();
        if("".equals(behind)){
            return input;
        }
        sb.append(input.substring(0,input.indexOf(".")));
        if(behind.charAt(0)=='{'){
            if(input.indexOf("}",input.indexOf("."))+1==input.length()) return input;
            sb.append(
                    input.substring(input.indexOf(".")+1,input.indexOf("}",input.indexOf("."))+1)
            );
            sb.append(".");
            sb.append(input.substring(input.indexOf("}",input.indexOf("."))+1));
            return sb.toString();
        }
       // System.out.println(sb);
        sb.append(behind);
        sb.append(".");
        sb.append(input.substring(input.indexOf(".")+behind.length()+1));
        return sb.toString();
    }
    public static String putPointInFirst(String s){
        return "."+s;
    }

    public static String getBehindPoint(String input){
        if(input.indexOf(".")==input.length()-1) return "";
        if(input.indexOf(".")<0) return null;
        String result="";
        int pos=input.indexOf(".");
        result=String.valueOf(input.charAt(pos+1));
        int ind_offset=2;
        if(input.charAt(pos+1)<='Z' && input.charAt(pos+1)>='A'){
            if(pos+2<input.length() &&  input.charAt(pos+2)=='\''){
                result+="'";
            }
        }else if(input.charAt(pos+1)<='z' && input.charAt(pos+1)>='a'){
            while(ind_offset+pos<input.length() && input.charAt(pos+ind_offset)<='z' && input.charAt(pos+ind_offset)>='a'){
                result+=input.charAt(pos+ind_offset);
                ind_offset++;
            }
        }else{
            return result;
        }
        return result;
    }
    public static Set<Tuple<String,String>> getPramset(String input_l,String input_right,Map<Integer,Tuple<String,String>> cfgexp_numbered){
        //System.out.println(input_l+"->"+input_right);
        Set<Tuple<String,String>> result=new HashSet<>();
        boolean change=false;
        result.add(new Tuple<>(input_l,input_right));
        //是终结符的情况
        String needFound="";
        while(true){
            for(Tuple item:result){
                //遍历整个集合，寻找item 点后能干出的推导式
                for(Integer i:cfgexp_numbered.keySet()){
                    if(cfgexp_numbered.get(i).key.equals(getBehindPoint((String)item.val))){
                        //System.out.println(cfgexp_numbered.get(i));
                        int c1=result.size();
                        result.add(new Tuple<>(cfgexp_numbered.get(i).key,putPointInFirst(cfgexp_numbered.get(i).val)));
                        int c2=result.size();
                        if(c1!=c2)
                        {
                            change=true;
                        }
                    }
                }
                if(change) break;
            }
            //System.out.println(result);
            if(change==false) break;
            change=false;
        }
        //System.out.println(result);
        return result;
    }
    public static void analyzeTry_fromBottom(String cfginput, List<InputItem> inputstr, String sortstr, Map<String,Object> ids, Map<String, IReductionStrategy> rss){

        Map<String,List<String>> cfgmap_source=CFGAnalyze(cfginput);
        StringBuilder cfginput2=new StringBuilder();

        //获取一份去掉{xxx}的产生式。  这是SB了。。应该直接用正则表达式干掉比较快。。
        int strpos=0;
        strpos=cfginput.indexOf("{");
        if(strpos>=0){
            cfginput2.append(cfginput.substring(0,strpos));
            strpos=cfginput.indexOf("}");
        }

        while (strpos<cfginput.length() || strpos<0){
            if(cfginput.indexOf("{",strpos)<0){
                cfginput2.append(cfginput.substring(strpos+1));
                break;
            }
            cfginput2.append(cfginput.substring(strpos+1,cfginput.indexOf("{",strpos)));

            strpos=cfginput.indexOf("}",strpos+1);
        }


        Map<String,List<String>> cfgmap_source2=CFGAnalyze(cfginput2.toString());
        Map<Integer,Tuple<String,String>> cfgexp_numbered=new HashMap<>();
        Map<Integer,Tuple<String,String>> cfgexp_numbered2=new HashMap<>();
        String recognized="";
        System.out.println(cfgmap_source);
        int exp_count=1;

        System.out.println("Setp 1:产生式编号...");
        for(String s:getInputQuery(sortstr)){
            for(String s2:cfgmap_source.get(s)){
                cfgexp_numbered.put(exp_count,new Tuple<>(s,s2));
                exp_count++;
            }
        }
        exp_count=1;
        for(String s:getInputQuery(sortstr)){
            for(String s2:cfgmap_source2.get(s)){
                cfgexp_numbered2.put(exp_count,new Tuple<>(s,s2));
                exp_count++;
            }
        }



        //将语义规则对应到产生式
        Map<Integer,IReductionStrategy> strategyMap=new HashMap<>();
        for(Integer key: cfgexp_numbered2.keySet()){
            Tuple<String,String> ts=cfgexp_numbered2.get(key);
            System.out.println(">>>"+ts.val);
            for(Integer key2: cfgexp_numbered2.keySet()){
                Tuple<String,String> ts2=cfgexp_numbered.get(key2);
                //System.out.println(ts2);
                Pattern pattern=Pattern.compile("\\{[a-zA-Z]\\d*\\}");
                if(ts2==null) continue;
                Matcher m=pattern.matcher(ts2.val);
                if(m.find() && ts2.val.replaceAll("\\{[a-zA-Z]\\d*\\}","").equals(ts.val)){
                    String s=m.group().replaceAll("\\{","").replaceAll("\\}","");
                    strategyMap.put(key,rss.get(s));
                    System.out.println(ts2.val+" get");
                }
            }
        }

        System.out.println(strategyMap);

        System.out.println("编号结果:");
        System.out.println(cfgexp_numbered+"\n");



        System.out.println("step 2:拓广文法...");
        cfgexp_numbered.put(0,new Tuple<>(getInputQuery(sortstr).peek()+"'",getInputQuery(sortstr).peek()));
        System.out.println(cfgexp_numbered+"\n");


        //转换集合
        ////KEY=状态编号，val=转换集合
        Map<Integer,Set<TransitionEdge>> transitionMap=new HashMap<>();

        Map<String,Set<Tuple<String,String>>> pramSets=new HashMap<>();
        int curProcess_pram=0;
        pramSets.put("I0",getPramset(cfgexp_numbered.get(0).key,putPointInFirst(cfgexp_numbered.get(0).val),cfgexp_numbered));

        System.out.println("Step 3:求所有项目集合I_x..."+pramSets);

        //求所有项目集I_x,一直循环，直到项目及不改变
        while(curProcess_pram<pramSets.size()){
            //处理当前项目集合
            Set<Tuple<String,String>> curPram=pramSets.get("I"+curProcess_pram);
            Set<TransitionEdge> transitionEdges=new HashSet<>();
            System.out.println("Process I"+curProcess_pram+"=====================================");
            System.out.println(curPram+"\n");
            Set<String> behindWord=new HashSet<>();
            for(Tuple p:curPram){
                if(behindWord.contains(getBehindPoint ((String) p.val))) continue; //该符已被处理

                System.out.print("process pI:"+curProcess_pram+","+p+":");
                //寻找点后面是相同符号的集合
                Set<Tuple<String,String>> requestSet=new HashSet<>();
                for(Tuple tuple:curPram){
                    if(shiftPointForward(shiftPointForward((String) tuple.val)).equals((String)tuple.val)) continue;
                    if(getBehindPoint((String)tuple.val).equals(getBehindPoint((String)p.val))){
                        requestSet.add(tuple);
                    }
                }



                System.out.print("Move Forward == ");
                //寻找相同终结符的集合

                for(Tuple tuple:requestSet){
                    System.out.print(shiftPointForward((String) tuple.val)+",");
                }
                System.out.println();
                Set<Tuple<String,String>> gotSet=new HashSet<>();
                //移动后获取新的项目集合
                for(Tuple tuple:requestSet){
                    gotSet.addAll(getPramset((String)tuple.key,shiftPointForward((String) tuple.val),cfgexp_numbered));
                }

                if(!(gotSet.size()==0)){
                    if(pramSets.containsValue(gotSet)){
                        System.out.println("Already Exist.Skip");


                        //添加转换边
                        transitionEdges.add(new TransitionEdge(curProcess_pram,
                                (Integer) Tools.getKey_Pram(pramSets,gotSet),
                                getBehindPoint((String)p.val)));
                    }else{
                        System.out.println("New I"+(pramSets.size())+":"+gotSet);
                        pramSets.put("I"+pramSets.size(),gotSet);
                        //添加转换边
                        transitionEdges.add(new TransitionEdge(curProcess_pram,pramSets.size()-1,
                                getBehindPoint((String)p.val)));
                    }
                    behindWord.add(getBehindPoint ((String)p.val));
                }else{
                    System.out.println("skip");
                }

            }

            transitionMap.put(curProcess_pram,transitionEdges);

            curProcess_pram++;

        }

        System.out.println("=================项目集求解完成，共"+pramSets.size()+"个状态======================");
        System.out.println(pramSets);
        System.out.println("============================转换边集合======================");
        System.out.println(transitionMap+"\n");



        System.out.println("s"+cfginput2);
        Map<String,Map<String, Set<String>>> followAndFirstSet=
                getFullFirstAndFollowSet(cfginput2.toString(),String.valueOf(sortstr.charAt(0)));
        System.out.println(followAndFirstSet.get("FOLLOW"));

        System.out.println("============================================\nStep 4: 制表");

        Map<String,Object> tableInf=drawTable_fromBottom(cfgmap_source2,cfgexp_numbered2,pramSets,transitionMap,followAndFirstSet.get("FOLLOW"),sortstr.charAt(0)+"'");


        Set<String> TerminalSet=(Set<String>) tableInf.get("TerminalSet");
        Set<String> noTerminalSet= (Set<String>) tableInf.get("NotTerminalSet");
        Map<Integer,Set<FromBottomTableItem>> items=(Map<Integer, Set<FromBottomTableItem>>) tableInf.get("TableInf");
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>表格打印完成");
        System.out.println();

        System.out.println("step 6:=================开始处理输入序列================");
        Queue<InputItem> inputqueue=(Queue<InputItem>) (new LinkedList<>(inputstr));
        System.out.println("init: ");
        Stack<String> stack=new Stack<>();
        Stack<Attributions> attributionsStack=new Stack<>();
        inputqueue.add(new InputItem(new WordTuple(-10,"$")));
        stack.push("0");
        System.out.println(inputqueue+","+stack);
        int step=1;

        while(inputqueue.size()>=0 && !stack.isEmpty()){
            Tuple t=new Tuple(stack.peek(),inputqueue.peek().getTransContent().toString());
            if(((WordTuple)inputqueue.peek().getTransContent()).getId()==11){
                t.val="id";
            }
            System.out.println("step "+step+":"+inputqueue+" , "+stack+" =>process: "+t);
            //获取对应表项
            Set<FromBottomTableItem> item=items.get(Integer.parseInt((String)t.key));

            boolean process=false;
            for(FromBottomTableItem fi:item){
                if(fi.targetCon.equals(t.val)){
                    process=true;
                    System.out.println(fi);
                    switch (fi.pw){
                        case S:  //移进
                            recognized+=inputqueue.peek().getTransContent().toString();
                            Attributions tmp_a=new Attributions();
                            if(((WordTuple)inputqueue.peek().getTransContent()).getId()==11){
                                tmp_a.attributes.put("val",Double.valueOf(inputqueue.peek().getTransContent().toString()));
                                System.out.println("found id="+tmp_a.getVal("val"));
                            }
                            attributionsStack.push(tmp_a);
                            inputqueue.poll();
                            stack.push((String)t.val);
                            stack.push(String.valueOf(fi.state));


                            System.out.println(">>>移进");

                            break;
                        case R:
                            Tuple<String,String> exp=cfgexp_numbered2.get(fi.state);
                            System.out.println(">>>按"+exp.key+"->"+exp.val+"归约");
                            //找出对应标记的文法
                            Object o=null;
                            for(Integer key:cfgexp_numbered2.keySet()){
                                if(cfgexp_numbered2.get(key).equals(exp)){
                                    IReductionStrategy iReductionStrategy=strategyMap.get(key);
                                    o=iReductionStrategy.inducation(ids,attributionsStack);
                                    System.out.println("output ="+((Attributions)o).getVal("val"));
                                }
                            }

                            Queue<String> gyqueue=getInputQuery((String)exp.val);
                            for(int i=0;i<gyqueue.size();i++){
                                stack.pop();
                                stack.pop();
                                attributionsStack.pop();
                            }

                            Tuple<String,String> e2=new Tuple<>(stack.peek(),exp.key);
                            stack.push((String)exp.key);
                            attributionsStack.push((Attributions)o);
                            //寻找要压入的状态
                            Set<FromBottomTableItem> i2=items.get(Integer.parseInt((String)e2.key));
                            for(FromBottomTableItem f2:i2){
                                if(f2.targetCon.equals(e2.val)){
                                    stack.push(String.valueOf(f2.state));
                                }
                            }

                            break;
                        case ACC:
                            System.out.println("ACC!! Suceess\n输入:"+inputstr+" 识别=> "+recognized);

                            stack.clear();
                            inputqueue.clear();
                            break;
                    }
                    break;
                }
            }

            //出错处理
            if(!process){
                System.out.println("遇到意外符号..."+inputqueue.peek());
                //弹栈直到有非终结符转移
                while(!stack.isEmpty()){
                    int peekstate=Integer.parseInt(stack.peek());
                    //System.out.println(transitionMap.get(peekstate));
                    boolean canTrans=false;

                    for(TransitionEdge te:transitionMap.get(peekstate)){
                        if(noTerminalSet.contains(te.context)) {
                            canTrans=true;
                            break;
                        }
                    }
                    if(canTrans)
                        break;
                    System.out.println("弹栈");
                    stack.pop();
                    stack.pop();
                }

                //处理输入队列
                while (inputqueue.size()>0){
                    boolean canTran=false;
                    Set<FromBottomTableItem> transset=items.get(Integer.parseInt(stack.peek()));
                    for(FromBottomTableItem fti:transset){
                        if(fti.targetCon.equals(inputqueue.peek())){
                            canTran=true;
                        }
                    }
                    if(!canTran){
                        System.out.println("忽略输入队列:"+inputqueue.peek());
                        inputqueue.poll();
                        break;
                    }
                }


            }
            step++;
            System.out.println();

        }

        System.out.println();
    }



    public static void main(String[] args){
        Map<String,Object> ids=new HashMap<>();   //标识符名 , 值  用不上，因为本例子都是直接用常数进行计算。
        Map<String, IReductionStrategy> rss=new HashMap<>();   //语义规则映射

        //定义归约策略map (语义规则)   用lambda表达式直接实现语义规则接口。 参数1:标识符集合(本例用不上)  参数2:当前属性栈
        rss.put("S1",(idset,a)->{
           if(a.size()<2) throw new RuntimeException();
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",(double)(a.get(a.size()-1).getVal("val"))+(double)( a.get(a.size()-3).getVal("val")));
            return  attributions;
        });
        rss.put("S2",(idset,a)->{
            if(a.size()<2) throw new RuntimeException();
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",(double)(a.get(a.size()-3).getVal("val"))-(double)( a.get(a.size()-1).getVal("val")));
            return  attributions;
        });
        rss.put("S3",(idset,a)->{
            if(a.size()<1) throw new RuntimeException();
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",(double)(a.get(a.size()-1).getVal("val")));
            return  attributions;
        });
        rss.put("S4",(idset,a)->{
            if(a.size()<2) throw new RuntimeException();
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",(double)(a.get(a.size()-1).getVal("val"))*(double)( a.get(a.size()-3).getVal("val")));
            return  attributions;
        });
        rss.put("S5",(idset,a)->{
            if(a.size()<2) throw new RuntimeException();
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",(double)(a.get(a.size()-3).getVal("val"))/(double) ( a.get(a.size()-1).getVal("val")));
            return  attributions;
        });
        rss.put("S6",(idset,a)->{
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",a.get(a.size()-1).getVal("val"));
            return attributions;
        });
        rss.put("S7",(idset,a)->{
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",a.get(a.size()-2).getVal("val"));
            return attributions;
        });
        rss.put("S8",(idset,a)->{
            Attributions attributions=new Attributions();
            attributions.attributes.put("val",a.get(a.size()-1).getVal("val"));
            return attributions;
        });


        //尝试解析一个句子
        analyzeTry_fromBottom("E->E+T{S1}|E-T{S2}|T{S3}\nT->T*F{S4}|T/F{S5}|F{S6}\nF->(E){S7}|id{S8}",
                tokenlizer.tokenlize("9/4*2+8-7"),"ETF",
                ids,rss);




    }
}
