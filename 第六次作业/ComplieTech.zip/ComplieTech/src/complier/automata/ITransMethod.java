package complier.automata;

//迁移函数方法接口
public interface ITransMethod {
    void trans(InfCollection infCollection, String tranContent);
}