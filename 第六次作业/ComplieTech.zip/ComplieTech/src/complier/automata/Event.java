package complier.automata;

public interface Event {
    public Object doEvent(Object... objs);
}
