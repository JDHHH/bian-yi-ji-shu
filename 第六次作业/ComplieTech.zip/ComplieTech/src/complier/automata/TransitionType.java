package complier.automata;

import java.io.Serializable;

//迁移类型。 关键词\任意名\记号
public enum TransitionType implements Serializable {
    STR,WORDTYPE
}
