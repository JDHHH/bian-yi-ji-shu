package complier.automata;

import java.util.List;

public interface IInputable {
    public List<InputItem> toInputList(String input);
}
