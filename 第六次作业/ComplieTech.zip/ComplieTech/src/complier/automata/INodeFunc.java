package complier.automata;


//节点方法接口
public interface INodeFunc{
    Object doWork(InfCollection infCollection, Object... objs);
}