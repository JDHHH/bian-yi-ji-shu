package complier.automata;

import java.util.Set;

public interface ISetProcess<T> {
    Set<T> processSet(Set<T> s);
}
