package complier.tokenlization;

import complier.Attributions;

import java.util.Map;
import java.util.Stack;
import java.util.jar.Attributes;

public interface IReductionStrategy {
    //返回综合属性
    Object inducation(Map<String,Object> ids,Stack<Attributions> attributions);


}
