package complier;

public class TransitionEdge {
    public int from;
    public int to;
    public String context="";
    public TransitionEdge(int f,int t,String c){
        this.from=f;
        this.to=t;
        this.context=c;
    }

    @Override
    public String toString() {
        return from+"->"+to+","+context;
    }
}
