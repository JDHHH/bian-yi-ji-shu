package complier;

import java.util.HashMap;
import java.util.Map;

public class Attributions {
    Map<String,Object> attributes=new HashMap<>();// key=属性名 val=属性值
    public Object getVal(String attributeName){
        return attributes.get(attributeName);
    }
}
